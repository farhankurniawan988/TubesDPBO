/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package DPBOUI;

/**
 *
 * @author Farhan Kurniawan
 */
import java.util.ArrayList;
import java.util.List;

public class Produksi {
    private List<BahanBaku> daftarBahan = new ArrayList<>();

    public void tambahBahan(BahanBaku bahan) {
        daftarBahan.add(bahan);
    }

    public void cekKualitasSemuaBahan() {
        for (BahanBaku bahan : daftarBahan) {
            bahan.setKualitasTeruji(true); // Simulasi: Semua bahan dianggap lolos uji
        }
    }

    public List<BahanBaku> getDaftarBahan() {
        return daftarBahan;
    }
}

