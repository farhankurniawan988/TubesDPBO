/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package DPBOUI;

/**
 *
 * @author Farhan Kurniawan
 */
import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class Main {
    private Produksi produksi = new Produksi();
    private DefaultListModel<String> bahanListModel = new DefaultListModel<>();
    private JTextArea laporanArea;

    public Main() {
        // Frame utama
        JFrame frame = new JFrame("Sistem Pengecekan Kualitas Bahan Baku");
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.setSize(600, 400);
        frame.setLayout(new BorderLayout());

        // Panel atas: Tambah bahan
        JPanel topPanel = new JPanel(new FlowLayout());
        JTextField namaBahanField = new JTextField(20);
        JButton tambahBahanButton = new JButton("Tambah Bahan");
        topPanel.add(new JLabel("Nama Bahan:"));
        topPanel.add(namaBahanField);
        topPanel.add(tambahBahanButton);

        // Panel kiri: Daftar bahan
        JPanel leftPanel = new JPanel(new BorderLayout());
        JList<String> bahanList = new JList<>(bahanListModel);
        leftPanel.add(new JLabel("Daftar Bahan:"), BorderLayout.NORTH);
        leftPanel.add(new JScrollPane(bahanList), BorderLayout.CENTER);

        // Panel tengah: Laporan
        JPanel centerPanel = new JPanel(new BorderLayout());
        laporanArea = new JTextArea();
        laporanArea.setEditable(false);
        centerPanel.add(new JLabel("Laporan Kualitas:"), BorderLayout.NORTH);
        centerPanel.add(new JScrollPane(laporanArea), BorderLayout.CENTER);

        // Panel bawah: Tombol aksi
        JPanel bottomPanel = new JPanel(new FlowLayout());
        JButton cekKualitasButton = new JButton("Cek Kualitas");
        JButton lihatLaporanButton = new JButton("Lihat Laporan");
        bottomPanel.add(cekKualitasButton);
        bottomPanel.add(lihatLaporanButton);

        // Tambahkan panel ke frame
        frame.add(topPanel, BorderLayout.NORTH);
        frame.add(leftPanel, BorderLayout.WEST);
        frame.add(centerPanel, BorderLayout.CENTER);
        frame.add(bottomPanel, BorderLayout.SOUTH);

        // Event Listener
        tambahBahanButton.addActionListener(e -> {
            String namaBahan = namaBahanField.getText().trim();
            if (!namaBahan.isEmpty()) {
                produksi.tambahBahan(new BahanBaku(namaBahan, false));
                bahanListModel.addElement(namaBahan);
                namaBahanField.setText("");
                JOptionPane.showMessageDialog(frame, "Bahan berhasil ditambahkan!");
            } else {
                JOptionPane.showMessageDialog(frame, "Nama bahan tidak boleh kosong!");
            }
        });

        cekKualitasButton.addActionListener(e -> {
            produksi.cekKualitasSemuaBahan();
            JOptionPane.showMessageDialog(frame, "Kualitas semua bahan telah diperiksa!");
        });

        lihatLaporanButton.addActionListener(e -> {
            StringBuilder laporan = new StringBuilder();
            for (BahanBaku bahan : produksi.getDaftarBahan()) {
                laporan.append("- ").append(bahan.getNama()).append(": ")
                        .append(bahan.isKualitasTeruji() ? "Lolos" : "Tidak Lolos").append("\n");
            }
            laporanArea.setText(laporan.toString());
        });

        // Tampilkan frame
        frame.setVisible(true);
    }

    public static void main(String[] args) {
        SwingUtilities.invokeLater(Main::new);
    }
}

