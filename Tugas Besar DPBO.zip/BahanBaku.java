/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package DPBOUI;

/**
 *
 * @author Farhan Kurniawan
 */
public class BahanBaku {
    private String nama;
    private boolean kualitasTeruji;

    public BahanBaku(String nama, boolean kualitasTeruji) {
        this.nama = nama;
        this.kualitasTeruji = kualitasTeruji;
    }

    public String getNama() {
        return nama;
    }

    public boolean isKualitasTeruji() {
        return kualitasTeruji;
    }

    public void setKualitasTeruji(boolean kualitasTeruji) {
        this.kualitasTeruji = kualitasTeruji;
    }
}
